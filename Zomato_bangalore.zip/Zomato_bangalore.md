TABLE OF CONTENT

1.  Loading the dataset: Load the data and import the libraries.
2.  Data Cleaning:

> * Deleting redundant columns.
> * Renaming the columns.
> * Dropping duplicates.
> * Cleaning individual columns.
> * Remove the NaN values from the dataset
> * Some Transformations


3. Regression Analysis

> * Linear Regression
> * Decision Tree Regression
> * Random Forest Regression

4. Data Visualization: Using plots to find relations between the features.

> * Restaurants delivering Online or not
> * Restaurants allowing table booking or not
> * Table booking Rate vs Rate
> * Best Location
> * Relation between Location and Rating
> * Restaurant Type
> * Types of Services
> * No. of restaurants in a Location
> * Restaurant type
> * Most famous restaurant chains in Bengaluru


```python
import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
```


```python
#Importing Libraries
import seaborn as sb
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LogisticRegression
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn.metrics import r2_score
import numpy as np
import pandas as pd
from sklearn.preprocessing import RobustScaler, MinMaxScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, VotingClassifier, AdaBoostClassifier
from sklearn.model_selection import cross_validate, GridSearchCV, cross_val_score
from sklearn.metrics import classification_report
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from xgboost import XGBClassifier
#from lightgbm import LGBMClassifier
#from catboost import CatBoostClassifier
#from yellowbrick.cluster import KElbowVisualizer
#from sklearn.decomposition import PCA
#from sklearn.cluster import KMeans
import seaborn as sns
import matplotlib.pyplot as plt
import re
import warnings

warnings.simplefilter(action='ignore', category=Warning)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', 500)
```


```python
#reading the dataset
zomato_real=pd.read_csv("D:/tuktuk important documents/SUMMER SEM/ML/PROJECT/zomato.csv")
zomato_real.head() # prints the first 5 rows of a DataFrame
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>url</th>
      <th>address</th>
      <th>name</th>
      <th>online_order</th>
      <th>book_table</th>
      <th>rate</th>
      <th>votes</th>
      <th>phone</th>
      <th>location</th>
      <th>rest_type</th>
      <th>dish_liked</th>
      <th>cuisines</th>
      <th>approx_cost(for two people)</th>
      <th>reviews_list</th>
      <th>menu_item</th>
      <th>listed_in(type)</th>
      <th>listed_in(city)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>https://www.zomato.com/bangalore/jalsa-banasha...</td>
      <td>942, 21st Main Road, 2nd Stage, Banashankari, ...</td>
      <td>Jalsa</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>4.1/5</td>
      <td>775</td>
      <td>080 42297555\r\n+91 9743772233</td>
      <td>Banashankari</td>
      <td>Casual Dining</td>
      <td>Pasta, Lunch Buffet, Masala Papad, Paneer Laja...</td>
      <td>North Indian, Mughlai, Chinese</td>
      <td>800</td>
      <td>[('Rated 4.0', 'RATED\n  A beautiful place to ...</td>
      <td>[]</td>
      <td>Buffet</td>
      <td>Banashankari</td>
    </tr>
    <tr>
      <th>1</th>
      <td>https://www.zomato.com/bangalore/spice-elephan...</td>
      <td>2nd Floor, 80 Feet Road, Near Big Bazaar, 6th ...</td>
      <td>Spice Elephant</td>
      <td>Yes</td>
      <td>No</td>
      <td>4.1/5</td>
      <td>787</td>
      <td>080 41714161</td>
      <td>Banashankari</td>
      <td>Casual Dining</td>
      <td>Momos, Lunch Buffet, Chocolate Nirvana, Thai G...</td>
      <td>Chinese, North Indian, Thai</td>
      <td>800</td>
      <td>[('Rated 4.0', 'RATED\n  Had been here for din...</td>
      <td>[]</td>
      <td>Buffet</td>
      <td>Banashankari</td>
    </tr>
    <tr>
      <th>2</th>
      <td>https://www.zomato.com/SanchurroBangalore?cont...</td>
      <td>1112, Next to KIMS Medical College, 17th Cross...</td>
      <td>San Churro Cafe</td>
      <td>Yes</td>
      <td>No</td>
      <td>3.8/5</td>
      <td>918</td>
      <td>+91 9663487993</td>
      <td>Banashankari</td>
      <td>Cafe, Casual Dining</td>
      <td>Churros, Cannelloni, Minestrone Soup, Hot Choc...</td>
      <td>Cafe, Mexican, Italian</td>
      <td>800</td>
      <td>[('Rated 3.0', "RATED\n  Ambience is not that ...</td>
      <td>[]</td>
      <td>Buffet</td>
      <td>Banashankari</td>
    </tr>
    <tr>
      <th>3</th>
      <td>https://www.zomato.com/bangalore/addhuri-udupi...</td>
      <td>1st Floor, Annakuteera, 3rd Stage, Banashankar...</td>
      <td>Addhuri Udupi Bhojana</td>
      <td>No</td>
      <td>No</td>
      <td>3.7/5</td>
      <td>88</td>
      <td>+91 9620009302</td>
      <td>Banashankari</td>
      <td>Quick Bites</td>
      <td>Masala Dosa</td>
      <td>South Indian, North Indian</td>
      <td>300</td>
      <td>[('Rated 4.0', "RATED\n  Great food and proper...</td>
      <td>[]</td>
      <td>Buffet</td>
      <td>Banashankari</td>
    </tr>
    <tr>
      <th>4</th>
      <td>https://www.zomato.com/bangalore/grand-village...</td>
      <td>10, 3rd Floor, Lakshmi Associates, Gandhi Baza...</td>
      <td>Grand Village</td>
      <td>No</td>
      <td>No</td>
      <td>3.8/5</td>
      <td>166</td>
      <td>+91 8026612447\r\n+91 9901210005</td>
      <td>Basavanagudi</td>
      <td>Casual Dining</td>
      <td>Panipuri, Gol Gappe</td>
      <td>North Indian, Rajasthani</td>
      <td>600</td>
      <td>[('Rated 4.0', 'RATED\n  Very good restaurant ...</td>
      <td>[]</td>
      <td>Buffet</td>
      <td>Banashankari</td>
    </tr>
  </tbody>
</table>
</div>




```python
zomato_real.info()

```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 51717 entries, 0 to 51716
    Data columns (total 17 columns):
     #   Column                       Non-Null Count  Dtype 
    ---  ------                       --------------  ----- 
     0   url                          51717 non-null  object
     1   address                      51717 non-null  object
     2   name                         51717 non-null  object
     3   online_order                 51717 non-null  object
     4   book_table                   51717 non-null  object
     5   rate                         43942 non-null  object
     6   votes                        51717 non-null  int64 
     7   phone                        50509 non-null  object
     8   location                     51696 non-null  object
     9   rest_type                    51490 non-null  object
     10  dish_liked                   23639 non-null  object
     11  cuisines                     51672 non-null  object
     12  approx_cost(for two people)  51371 non-null  object
     13  reviews_list                 51717 non-null  object
     14  menu_item                    51717 non-null  object
     15  listed_in(type)              51717 non-null  object
     16  listed_in(city)              51717 non-null  object
    dtypes: int64(1), object(16)
    memory usage: 6.7+ MB
    


```python
#Deleting Unnnecessary Columns
zomato=zomato_real.drop(['url','dish_liked','phone'],axis=1) #Dropping the column "dish_liked", "phone", "url" and saving the new dataset as "zomato"

```


```python
zomato.head() # looking at the dataset after transformation

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>address</th>
      <th>name</th>
      <th>online_order</th>
      <th>book_table</th>
      <th>rate</th>
      <th>votes</th>
      <th>location</th>
      <th>rest_type</th>
      <th>cuisines</th>
      <th>approx_cost(for two people)</th>
      <th>reviews_list</th>
      <th>menu_item</th>
      <th>listed_in(type)</th>
      <th>listed_in(city)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>942, 21st Main Road, 2nd Stage, Banashankari, ...</td>
      <td>Jalsa</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>4.1/5</td>
      <td>775</td>
      <td>Banashankari</td>
      <td>Casual Dining</td>
      <td>North Indian, Mughlai, Chinese</td>
      <td>800</td>
      <td>[('Rated 4.0', 'RATED\n  A beautiful place to ...</td>
      <td>[]</td>
      <td>Buffet</td>
      <td>Banashankari</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2nd Floor, 80 Feet Road, Near Big Bazaar, 6th ...</td>
      <td>Spice Elephant</td>
      <td>Yes</td>
      <td>No</td>
      <td>4.1/5</td>
      <td>787</td>
      <td>Banashankari</td>
      <td>Casual Dining</td>
      <td>Chinese, North Indian, Thai</td>
      <td>800</td>
      <td>[('Rated 4.0', 'RATED\n  Had been here for din...</td>
      <td>[]</td>
      <td>Buffet</td>
      <td>Banashankari</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1112, Next to KIMS Medical College, 17th Cross...</td>
      <td>San Churro Cafe</td>
      <td>Yes</td>
      <td>No</td>
      <td>3.8/5</td>
      <td>918</td>
      <td>Banashankari</td>
      <td>Cafe, Casual Dining</td>
      <td>Cafe, Mexican, Italian</td>
      <td>800</td>
      <td>[('Rated 3.0', "RATED\n  Ambience is not that ...</td>
      <td>[]</td>
      <td>Buffet</td>
      <td>Banashankari</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1st Floor, Annakuteera, 3rd Stage, Banashankar...</td>
      <td>Addhuri Udupi Bhojana</td>
      <td>No</td>
      <td>No</td>
      <td>3.7/5</td>
      <td>88</td>
      <td>Banashankari</td>
      <td>Quick Bites</td>
      <td>South Indian, North Indian</td>
      <td>300</td>
      <td>[('Rated 4.0', "RATED\n  Great food and proper...</td>
      <td>[]</td>
      <td>Buffet</td>
      <td>Banashankari</td>
    </tr>
    <tr>
      <th>4</th>
      <td>10, 3rd Floor, Lakshmi Associates, Gandhi Baza...</td>
      <td>Grand Village</td>
      <td>No</td>
      <td>No</td>
      <td>3.8/5</td>
      <td>166</td>
      <td>Basavanagudi</td>
      <td>Casual Dining</td>
      <td>North Indian, Rajasthani</td>
      <td>600</td>
      <td>[('Rated 4.0', 'RATED\n  Very good restaurant ...</td>
      <td>[]</td>
      <td>Buffet</td>
      <td>Banashankari</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Removing the Duplicates
zomato.duplicated().sum()
zomato.drop_duplicates(inplace=True)
zomato.head() # looking at the dataset after transformation
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>address</th>
      <th>name</th>
      <th>online_order</th>
      <th>book_table</th>
      <th>rate</th>
      <th>votes</th>
      <th>location</th>
      <th>rest_type</th>
      <th>cuisines</th>
      <th>approx_cost(for two people)</th>
      <th>reviews_list</th>
      <th>menu_item</th>
      <th>listed_in(type)</th>
      <th>listed_in(city)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>942, 21st Main Road, 2nd Stage, Banashankari, ...</td>
      <td>Jalsa</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>4.1/5</td>
      <td>775</td>
      <td>Banashankari</td>
      <td>Casual Dining</td>
      <td>North Indian, Mughlai, Chinese</td>
      <td>800</td>
      <td>[('Rated 4.0', 'RATED\n  A beautiful place to ...</td>
      <td>[]</td>
      <td>Buffet</td>
      <td>Banashankari</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2nd Floor, 80 Feet Road, Near Big Bazaar, 6th ...</td>
      <td>Spice Elephant</td>
      <td>Yes</td>
      <td>No</td>
      <td>4.1/5</td>
      <td>787</td>
      <td>Banashankari</td>
      <td>Casual Dining</td>
      <td>Chinese, North Indian, Thai</td>
      <td>800</td>
      <td>[('Rated 4.0', 'RATED\n  Had been here for din...</td>
      <td>[]</td>
      <td>Buffet</td>
      <td>Banashankari</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1112, Next to KIMS Medical College, 17th Cross...</td>
      <td>San Churro Cafe</td>
      <td>Yes</td>
      <td>No</td>
      <td>3.8/5</td>
      <td>918</td>
      <td>Banashankari</td>
      <td>Cafe, Casual Dining</td>
      <td>Cafe, Mexican, Italian</td>
      <td>800</td>
      <td>[('Rated 3.0', "RATED\n  Ambience is not that ...</td>
      <td>[]</td>
      <td>Buffet</td>
      <td>Banashankari</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1st Floor, Annakuteera, 3rd Stage, Banashankar...</td>
      <td>Addhuri Udupi Bhojana</td>
      <td>No</td>
      <td>No</td>
      <td>3.7/5</td>
      <td>88</td>
      <td>Banashankari</td>
      <td>Quick Bites</td>
      <td>South Indian, North Indian</td>
      <td>300</td>
      <td>[('Rated 4.0', "RATED\n  Great food and proper...</td>
      <td>[]</td>
      <td>Buffet</td>
      <td>Banashankari</td>
    </tr>
    <tr>
      <th>4</th>
      <td>10, 3rd Floor, Lakshmi Associates, Gandhi Baza...</td>
      <td>Grand Village</td>
      <td>No</td>
      <td>No</td>
      <td>3.8/5</td>
      <td>166</td>
      <td>Basavanagudi</td>
      <td>Casual Dining</td>
      <td>North Indian, Rajasthani</td>
      <td>600</td>
      <td>[('Rated 4.0', 'RATED\n  Very good restaurant ...</td>
      <td>[]</td>
      <td>Buffet</td>
      <td>Banashankari</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Remove the NaN values from the dataset
zomato.isnull().sum()
zomato.dropna(how='any',inplace=True)
zomato.info() #.info() function is used to get a concise summary of the dataframe
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 43499 entries, 0 to 51716
    Data columns (total 14 columns):
     #   Column                       Non-Null Count  Dtype 
    ---  ------                       --------------  ----- 
     0   address                      43499 non-null  object
     1   name                         43499 non-null  object
     2   online_order                 43499 non-null  object
     3   book_table                   43499 non-null  object
     4   rate                         43499 non-null  object
     5   votes                        43499 non-null  int64 
     6   location                     43499 non-null  object
     7   rest_type                    43499 non-null  object
     8   cuisines                     43499 non-null  object
     9   approx_cost(for two people)  43499 non-null  object
     10  reviews_list                 43499 non-null  object
     11  menu_item                    43499 non-null  object
     12  listed_in(type)              43499 non-null  object
     13  listed_in(city)              43499 non-null  object
    dtypes: int64(1), object(13)
    memory usage: 5.0+ MB
    


```python
#Reading Column Names
zomato.columns
```




    Index(['address', 'name', 'online_order', 'book_table', 'rate', 'votes', 'location', 'rest_type', 'cuisines', 'approx_cost(for two people)', 'reviews_list', 'menu_item', 'listed_in(type)', 'listed_in(city)'], dtype='object')




```python
#Changing the column names
zomato = zomato.rename(columns={'approx_cost(for two people)':'cost','listed_in(type)':'type',
                                  'listed_in(city)':'city'})
zomato.columns
```




    Index(['address', 'name', 'online_order', 'book_table', 'rate', 'votes', 'location', 'rest_type', 'cuisines', 'cost', 'reviews_list', 'menu_item', 'type', 'city'], dtype='object')




```python
#Some Transformations
zomato['cost'] = zomato['cost'].astype(str) #Changing the cost to string
zomato['cost'] = zomato['cost'].apply(lambda x: x.replace(',','.')) #Using lambda function to replace ',' from cost
zomato['cost'] = zomato['cost'].astype(float) # Changing the cost to Float
zomato.info() # looking at the dataset information after transformation
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 43499 entries, 0 to 51716
    Data columns (total 14 columns):
     #   Column        Non-Null Count  Dtype  
    ---  ------        --------------  -----  
     0   address       43499 non-null  object 
     1   name          43499 non-null  object 
     2   online_order  43499 non-null  object 
     3   book_table    43499 non-null  object 
     4   rate          43499 non-null  object 
     5   votes         43499 non-null  int64  
     6   location      43499 non-null  object 
     7   rest_type     43499 non-null  object 
     8   cuisines      43499 non-null  object 
     9   cost          43499 non-null  float64
     10  reviews_list  43499 non-null  object 
     11  menu_item     43499 non-null  object 
     12  type          43499 non-null  object 
     13  city          43499 non-null  object 
    dtypes: float64(1), int64(1), object(12)
    memory usage: 5.0+ MB
    


```python
#Reading uninque values from the Rate column
zomato['rate'].unique()
```




    array(['4.1/5', '3.8/5', '3.7/5', '3.6/5', '4.6/5', '4.0/5', '4.2/5',
           '3.9/5', '3.1/5', '3.0/5', '3.2/5', '3.3/5', '2.8/5', '4.4/5',
           '4.3/5', 'NEW', '2.9/5', '3.5/5', '2.6/5', '3.8 /5', '3.4/5',
           '4.5/5', '2.5/5', '2.7/5', '4.7/5', '2.4/5', '2.2/5', '2.3/5',
           '3.4 /5', '-', '3.6 /5', '4.8/5', '3.9 /5', '4.2 /5', '4.0 /5',
           '4.1 /5', '3.7 /5', '3.1 /5', '2.9 /5', '3.3 /5', '2.8 /5',
           '3.5 /5', '2.7 /5', '2.5 /5', '3.2 /5', '2.6 /5', '4.5 /5',
           '4.3 /5', '4.4 /5', '4.9/5', '2.1/5', '2.0/5', '1.8/5', '4.6 /5',
           '4.9 /5', '3.0 /5', '4.8 /5', '2.3 /5', '4.7 /5', '2.4 /5',
           '2.1 /5', '2.2 /5', '2.0 /5', '1.8 /5'], dtype=object)




```python
#Removing '/5' from Rates
zomato = zomato.loc[zomato.rate !='NEW']
zomato = zomato.loc[zomato.rate !='-'].reset_index(drop=True)
remove_slash = lambda x: x.replace('/5', '') if type(x) == np.str else x
zomato.rate = zomato.rate.apply(remove_slash).str.strip().astype('float')
zomato['rate'].head() # looking at the dataset after transformation
```




    0    4.1
    1    4.1
    2    3.8
    3    3.7
    4    3.8
    Name: rate, dtype: float64




```python
# Adjust the column names
zomato.name = zomato.name.apply(lambda x:x.title())
zomato.online_order.replace(('Yes','No'),(True, False),inplace=True)
zomato.book_table.replace(('Yes','No'),(True, False),inplace=True)
zomato.head() # looking at the dataset after transformation
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>address</th>
      <th>name</th>
      <th>online_order</th>
      <th>book_table</th>
      <th>rate</th>
      <th>votes</th>
      <th>location</th>
      <th>rest_type</th>
      <th>cuisines</th>
      <th>cost</th>
      <th>reviews_list</th>
      <th>menu_item</th>
      <th>type</th>
      <th>city</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>942, 21st Main Road, 2nd Stage, Banashankari, ...</td>
      <td>Jalsa</td>
      <td>True</td>
      <td>True</td>
      <td>4.1</td>
      <td>775</td>
      <td>Banashankari</td>
      <td>Casual Dining</td>
      <td>North Indian, Mughlai, Chinese</td>
      <td>800.0</td>
      <td>[('Rated 4.0', 'RATED\n  A beautiful place to ...</td>
      <td>[]</td>
      <td>Buffet</td>
      <td>Banashankari</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2nd Floor, 80 Feet Road, Near Big Bazaar, 6th ...</td>
      <td>Spice Elephant</td>
      <td>True</td>
      <td>False</td>
      <td>4.1</td>
      <td>787</td>
      <td>Banashankari</td>
      <td>Casual Dining</td>
      <td>Chinese, North Indian, Thai</td>
      <td>800.0</td>
      <td>[('Rated 4.0', 'RATED\n  Had been here for din...</td>
      <td>[]</td>
      <td>Buffet</td>
      <td>Banashankari</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1112, Next to KIMS Medical College, 17th Cross...</td>
      <td>San Churro Cafe</td>
      <td>True</td>
      <td>False</td>
      <td>3.8</td>
      <td>918</td>
      <td>Banashankari</td>
      <td>Cafe, Casual Dining</td>
      <td>Cafe, Mexican, Italian</td>
      <td>800.0</td>
      <td>[('Rated 3.0', "RATED\n  Ambience is not that ...</td>
      <td>[]</td>
      <td>Buffet</td>
      <td>Banashankari</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1st Floor, Annakuteera, 3rd Stage, Banashankar...</td>
      <td>Addhuri Udupi Bhojana</td>
      <td>False</td>
      <td>False</td>
      <td>3.7</td>
      <td>88</td>
      <td>Banashankari</td>
      <td>Quick Bites</td>
      <td>South Indian, North Indian</td>
      <td>300.0</td>
      <td>[('Rated 4.0', "RATED\n  Great food and proper...</td>
      <td>[]</td>
      <td>Buffet</td>
      <td>Banashankari</td>
    </tr>
    <tr>
      <th>4</th>
      <td>10, 3rd Floor, Lakshmi Associates, Gandhi Baza...</td>
      <td>Grand Village</td>
      <td>False</td>
      <td>False</td>
      <td>3.8</td>
      <td>166</td>
      <td>Basavanagudi</td>
      <td>Casual Dining</td>
      <td>North Indian, Rajasthani</td>
      <td>600.0</td>
      <td>[('Rated 4.0', 'RATED\n  Very good restaurant ...</td>
      <td>[]</td>
      <td>Buffet</td>
      <td>Banashankari</td>
    </tr>
  </tbody>
</table>
</div>




```python
zomato.cost.unique() # cheking the unique costs

```




    array([800.  , 300.  , 600.  , 700.  , 550.  , 500.  , 450.  , 650.  ,
           400.  , 900.  , 200.  , 750.  , 150.  , 850.  , 100.  ,   1.2 ,
           350.  , 250.  , 950.  ,   1.  ,   1.5 ,   1.3 , 199.  ,   1.1 ,
             1.6 , 230.  , 130.  ,   1.7 ,   1.35,   2.2 ,   1.4 ,   2.  ,
             1.8 ,   1.9 , 180.  , 330.  ,   2.5 ,   2.1 ,   3.  ,   2.8 ,
             3.4 ,  50.  ,  40.  ,   1.25,   3.5 ,   4.  ,   2.4 ,   2.6 ,
             1.45,  70.  ,   3.2 , 240.  ,   6.  ,   1.05,   2.3 ,   4.1 ,
           120.  ,   5.  ,   3.7 ,   1.65,   2.7 ,   4.5 ,  80.  ])




```python
#Encode the input Variables
def Encode(zomato):
    for column in zomato.columns[~zomato.columns.isin(['rate', 'cost', 'votes'])]:
        zomato[column] = zomato[column].factorize()[0]
    return zomato

zomato_en = Encode(zomato.copy())
zomato_en.head() # looking at the dataset after transformation
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>address</th>
      <th>name</th>
      <th>online_order</th>
      <th>book_table</th>
      <th>rate</th>
      <th>votes</th>
      <th>location</th>
      <th>rest_type</th>
      <th>cuisines</th>
      <th>cost</th>
      <th>reviews_list</th>
      <th>menu_item</th>
      <th>type</th>
      <th>city</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>4.1</td>
      <td>775</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>800.0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>4.1</td>
      <td>787</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>800.0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>2</td>
      <td>0</td>
      <td>1</td>
      <td>3.8</td>
      <td>918</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>800.0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>3</td>
      <td>1</td>
      <td>1</td>
      <td>3.7</td>
      <td>88</td>
      <td>0</td>
      <td>2</td>
      <td>3</td>
      <td>300.0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>4</td>
      <td>1</td>
      <td>1</td>
      <td>3.8</td>
      <td>166</td>
      <td>1</td>
      <td>0</td>
      <td>4</td>
      <td>600.0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
def grab_col_names(dataframe, cat_th=10, car_th=20):
    cat_cols = [col for col in dataframe.columns if dataframe[col].dtypes == "O"]

    num_but_cat = [col for col in dataframe.columns if dataframe[col].nunique() < cat_th and
                   dataframe[col].dtypes != "O"]

    cat_but_car = [col for col in dataframe.columns if dataframe[col].nunique() > car_th and
                   dataframe[col].dtypes == "O"]

    cat_cols = cat_cols + num_but_cat

    cat_cols = [col for col in cat_cols if col not in cat_but_car]

    num_cols = [col for col in dataframe.columns if dataframe[col].dtypes != "O"]

    num_cols = [col for col in num_cols if col not in num_but_cat]

    print(f"Observations: {dataframe.shape[0]}")
    print(f"Variables: {dataframe.shape[1]}")
    print(f'cat_cols: {len(cat_cols)}')
    print(f'num_cols: {len(num_cols)}')
    print(f'cat_but_car: {len(cat_but_car)}')
    print(f'num_but_cat: {len(num_but_cat)}')

    return cat_cols, num_cols, cat_but_car

cat_cols, num_cols, cat_but_car = grab_col_names(zomato_en)
```

    Observations: 41237
    Variables: 14
    cat_cols: 3
    num_cols: 11
    cat_but_car: 0
    num_but_cat: 3
    


```python
#Get Correlation between different variables
corr = zomato_en.corr(method='kendall')
plt.figure(figsize=(15,8))
sns.heatmap(corr, annot=True)
zomato_en.columns
```




    Index(['address', 'name', 'online_order', 'book_table', 'rate', 'votes', 'location', 'rest_type', 'cuisines', 'cost', 'reviews_list', 'menu_item', 'type', 'city'], dtype='object')




    
![png](output_18_1.png)
    


# The highest correlation between name and address  which is 0.62 which is not of very much concern. The second highest correlation is between reviews and city (0.61) which can be useful. The correlation coefficient b/w ratings and votes is also high (0.53)

# Data Visualization


## Cost vs rating


```python
plt.figure(figsize=(10,7))
sns.scatterplot(x="rate",y='cost',hue='online_order',data=zomato)
plt.show()
```


    
![png](output_22_0.png)
    



```python
#Restaurants delivering Online or not
sns.countplot(zomato['online_order'])
fig = plt.gcf()
fig.set_size_inches(10,10)
plt.title('Restaurants delivering online or Not')

```




    Text(0.5, 1.0, 'Restaurants delivering online or Not')




    
![png](output_23_1.png)
    


# resturant allowed table booking or not


```python
sns.countplot(zomato['book_table'])
fig = plt.gcf()
fig.set_size_inches(10,10)
plt.title('Restaurants allowing table booking or not')
```




    Text(0.5, 1.0, 'Restaurants allowing table booking or not')




    
![png](output_25_1.png)
    



```python
sns.countplot(zomato['book_table'])

# Set the figure size
fig = plt.gcf()
fig.set_size_inches(10, 10)

# Set the title
plt.title('Restaurants allowing table booking or not')

# Add legend
plt.legend(labels=['Not Allowed', 'Allowed'], loc='upper right')

# Show the plot
plt.show()
```


    
![png](output_26_0.png)
    


# location


```python
sns.countplot(zomato['city'])
sns.countplot(zomato['city']).set_xticklabels(sns.countplot(zomato['city']).get_xticklabels(), rotation=90, ha="right")
fig = plt.gcf()
fig.set_size_inches(13,13)
plt.title('Location wise count for restaurants')
```




    Text(0.5, 1.0, 'Location wise count for restaurants')




    
![png](output_28_1.png)
    



```python
# Aggregating the count of restaurants by city
city_counts = zomato['city'].value_counts()

# Plotting the pie chart
plt.figure(figsize=(13, 13))
patches, texts, autotexts = plt.pie(city_counts, labels=None, autopct='%1.1f%%', startangle=140)

# Adding a legend outside the pie chart
plt.legend(patches, city_counts.index, loc="center left", bbox_to_anchor=(1, 0.5), fontsize=10)
plt.title('Location wise count for restaurants')
plt.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.

# Display the pie chart
plt.show()
```


    
![png](output_29_0.png)
    


# location and rating


```python
# Calculate the number of restaurants and average rating for each city
city_counts = zomato['city'].value_counts()
city_avg_ratings = zomato.groupby('city')['rate'].mean()

# Create a DataFrame for plotting
city_data = pd.DataFrame({
    'city': city_counts.index,
    'restaurant_count': city_counts.values,
    'avg_rating': city_avg_ratings.loc[city_counts.index].values
})

# Plotting the bubble chart
plt.figure(figsize=(13, 9))
scatter = plt.scatter(
    city_data['city'],
    city_data['avg_rating'],
    s=city_data['restaurant_count'] * 10,  # Scale the size of bubbles
    c=city_data['avg_rating'],
    cmap='viridis',
    alpha=0.6,
    edgecolors="w",
    linewidth=0.5
)

# Add city names inside the bubbles
for i, txt in enumerate(city_data['city']):
    plt.annotate(txt, (city_data['city'][i], city_data['avg_rating'][i]), ha='center', va='center')

# Add color bar to represent the average rating
cbar = plt.colorbar(scatter)
cbar.set_label('Average Rating')

# Adding labels and title
plt.xlabel('City')
plt.ylabel('Average Rating')
plt.title('Location-wise Restaurant Count and Average Rating')

# Rotate x-axis labels for better readability
plt.xticks(rotation=90)

# Show the plot
plt.show()
```


    
![png](output_31_0.png)
    


# Types of services


```python
sns.countplot(zomato['type'])
sns.countplot(zomato['type']).set_xticklabels(sns.countplot(zomato['type']).get_xticklabels(), rotation=90, ha="right")
fig = plt.gcf()
fig.set_size_inches(15,15)
plt.title('Type of Service')
```




    Text(0.5, 1.0, 'Type of Service')




    
![png](output_33_1.png)
    


# no of resturant in location


```python
fig = plt.figure(figsize=(20,7))
loc = sns.countplot(x="location",data=zomato_real, palette = "Set1")
loc.set_xticklabels(loc.get_xticklabels(), rotation=90, ha="right")
plt.ylabel("Frequency",size=15)
plt.xlabel("Location",size=18)
loc
plt.title('NO. of restaurants in a Location',size = 20,pad=20)
```




    Text(0.5, 1.0, 'NO. of restaurants in a Location')




    
![png](output_35_1.png)
    


# Resturant type


```python
fig = plt.figure(figsize=(17,5))
rest = sns.countplot(x="rest_type",data=zomato_real, palette = "Set1")
rest.set_xticklabels(rest.get_xticklabels(), rotation=90, ha="right")
plt.ylabel("Frequency",size=15)
plt.xlabel("Restaurant type",size=15)
rest 
plt.title('Restaurant types',fontsize = 20 ,pad=20)
```




    Text(0.5, 1.0, 'Restaurant types')




    
![png](output_37_1.png)
    


# Most famous resturant chain in bengaluru


```python
plt.figure(figsize=(15,7))
chains=zomato_real['name'].value_counts()[:20]
sns.barplot(x=chains,y=chains.index,palette='Set1')
plt.title("Most famous restaurant chains in Bangaluru",size=20,pad=20)
plt.xlabel("Number of outlets",size=15)
```




    Text(0.5, 0, 'Number of outlets')




    
![png](output_39_1.png)
    

